class CfgRemoteExec {
    class Functions {
        mode = 2;
        jip = 0;
    };
    class Commands {
        mode = 2;
        jip = 0;
    };
};

#include "The-Programmer\theprogrammer_remoteExec_master.cpp"
