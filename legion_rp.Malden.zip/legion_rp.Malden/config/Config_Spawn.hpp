class SpawnPoints {
    class Civilian {
        displayName = "La Trinité";
        spawnMarker = "civ_spawn_1";
    };
};
