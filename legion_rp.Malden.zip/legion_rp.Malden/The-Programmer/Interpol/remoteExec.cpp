class max_interpol_fnc_updateInterpol {
    allowedTargets = 2;
};
class max_interpol_fnc_getInterpol {
    allowedTargets = 2;
};
class max_interpol_fnc_getCrimes {
    allowedTargets = 2;
};
class max_interpol_fnc_updateCrimes {
    allowedTargets = 2;
};
class max_interpol_fnc_interpolCrimeMenu {
    allowedTargets = 1;
};
class max_interpol_fnc_interpolMenuList {
    allowedTargets = 1;
};
class max_interpol_fnc_autoCrimes {
    allowedTargets = 2;
};