class IphoneXI_ArmyWakeup {
    name = "IphoneXI_ArmyWakeup";
    sound[] = {"The-programmer\Iphone_XI\sounds\ArmyWakeup.ogg", 1.0, 1};
    titles[] = {};
};
class IphoneXI_bahbahbah {
    name = "IphoneXI_bahbahbah";
    sound[] = {"The-programmer\Iphone_XI\sounds\bahbahbah.ogg", 1.0, 1};
    titles[] = {};
};
class IphoneXI_DontWorryBeHappy {
    name = "IphoneXI_DontWorryBeHappy";
    sound[] = {"The-programmer\Iphone_XI\sounds\DontWorryBeHappy.ogg", 1.0, 1};
    titles[] = {};
};
class IphoneXI_HurrDurr {
    name = "IphoneXI_HurrDurr";
    sound[] = {"The-programmer\Iphone_XI\sounds\HurrDurr.ogg", 1.0, 1};
    titles[] = {};
};
class IphoneXI_IsThatMyiPhone {
    name = "IphoneXI_IsThatMyiPhone";
    sound[] = {"The-programmer\Iphone_XI\sounds\IsThatMyiPhone.ogg", 1.0, 1};
    titles[] = {};
};
class IphoneXI_RocketShip {
    name = "IphoneXI_RocketShip";
    sound[] = {"The-programmer\Iphone_XI\sounds\RocketShip.ogg", 1.0, 1};
    titles[] = {};
};
class IphoneXI_SmokeWeed {
    name = "IphoneXI_SmokeWeed";
    sound[] = {"The-programmer\Iphone_XI\sounds\SmokeWeed.ogg", 1.0, 1};
    titles[] = {};
};
class IphoneXI_mario_mushroom {
    name = "IphoneXI_mario_mushroom";
    sound[] = {"The-programmer\Iphone_XI\sounds\mario_mushroom.ogg", 1.0, 1};
    titles[] = {};
};
class IphoneXI_classic_whistle {
    name = "IphoneXI_classic_whistle";
    sound[] = {"The-programmer\Iphone_XI\sounds\classic_whistle.ogg", 1.0, 1};
    titles[] = {};
};
class IphoneXI_Notif_iphone {
    name = "IphoneXI_Notif_iphone";
    sound[] = {"The-programmer\Iphone_XI\sounds\Apple.ogg", 1.0, 1};
    titles[] = {};
};
class IphoneXI_Samsung {
    name = "IphoneXI_Samsung";
    sound[] = {"The-programmer\Iphone_XI\sounds\Samsung.ogg", 1.0, 1};
    titles[] = {};
};