class the_programmer_iphone_xi_fnc_apps_getPlateInfo {
    allowedTargets = 2;
};
class the_programmer_iphone_xi_fnc_apps_searchPlateResult {
	allowedTargets = 1;
};