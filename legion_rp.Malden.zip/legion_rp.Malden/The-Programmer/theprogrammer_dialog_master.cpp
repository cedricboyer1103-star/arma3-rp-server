/*
    The-Programmer - Dialog Master
    Version corrigée - Seulement modules existants
*/

// ✅ Modules qui existent
#include "EffetsEcran\dialogs.cpp"
#include "KeyTransfer\dialogs.cpp"
#include "Radial_Menu\dialogs.cpp"
#include "Interpol\dialogs.cpp"
#include "Fourriere\dialogs.cpp"
#include "Iphone_XI\dialogs.cpp"
// ❌ Modules qui n'existent pas - commentés
// #include "Restrain\dialogs.cpp"
// #include "PermisPoints\dialogs.cpp"
// #include "Immatriculation\dialogs.cpp"
