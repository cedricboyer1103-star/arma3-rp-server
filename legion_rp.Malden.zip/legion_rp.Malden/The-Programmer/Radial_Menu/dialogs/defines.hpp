/*
    ═══════════════════════════════════════════════════════════════
    📱 defines.hpp - Radial Menu
    ═══════════════════════════════════════════════════════════════
    Dernière mise à jour : 2025-11-07 09:38:33
    Auteur : cedricboyer1103-star
    ═══════════════════════════════════════════════════════════════
*/

#include "..\..\..\dialogs\defines.hpp"

// ═══════════════════════════════════════════════════════════════
// CLASSES SPÉCIFIQUES AU MENU RADIAL
// ═══════════════════════════════════════════════════════════════

class Life_RscScrollBar {
    color[] = {1,1,1,0.6};
    colorActive[] = {1,1,1,1};
    colorDisabled[] = {1,1,1,0.3};
    thumb = "\A3\ui_f\data\gui\cfg\scrollbar\thumb_ca.paa";
    arrowEmpty = "\A3\ui_f\data\gui\cfg\scrollbar\arrowEmpty_ca.paa";
    arrowFull = "\A3\ui_f\data\gui\cfg\scrollbar\arrowFull_ca.paa";
    border = "\A3\ui_f\data\gui\cfg\scrollbar\border_ca.paa";
    shadow = 0;
    scrollSpeed = 0.06;
    width = 0;
    height = 0;
    autoScrollEnabled = 0;
    autoScrollSpeed = -1;
    autoScrollDelay = 5;
    autoScrollRewind = 0;
};

class Life_RscControlsGroup {
    type = CT_CONTROLS_GROUP;
    idc = -1;
    x = 0;
    y = 0;
    w = 1;
    h = 1;
    shadow = 0;
    style = ST_MULTI;
    
    class VScrollbar : Life_RscScrollBar {
        width = 0.021;
        autoScrollEnabled = 1;
    };
    
    class HScrollbar : Life_RscScrollBar {
        height = 0.028;
    };
    
    class Controls {};
};

class Life_RscControlsGroupNoScrollbars : Life_RscControlsGroup {
    class VScrollbar : VScrollbar {
        width = 0;
    };
    
    class HScrollbar : HScrollbar {
        height = 0;
    };
};

class Life_RscHud {
    idc = -1;
    type = CT_HUD;
    style = ST_PICTURE;
    colorBackground[] = {0,0,0,0};
    colorText[] = {1,1,1,1};
    font = "PuristaMedium";
    sizeEx = 0.042;
    h = 0.334;
    text = "";
};

// ═══════════════════════════════════════════════════════════════
// FIN DU FICHIER
// ═══════════════════════════════════════════════════════════════