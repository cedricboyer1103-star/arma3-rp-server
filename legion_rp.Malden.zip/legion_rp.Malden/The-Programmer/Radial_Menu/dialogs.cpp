#include "config_master.cpp"
#include "config_button.cpp"
#include "localization.hpp"
#include "dialogs\radial_menu.hpp"