class max_fourriere_fnc_fourriereMenu {
    allowedTargets = 1;
};
class max_fourriere_fnc_getFourriere {
    allowedTargets = 2;
};
class max_fourriere_fnc_updateFourriere {
	allowedTargets = 2;
};
class max_fourriere_fnc_updateVehicle {
	allowedTargets = 2;
};
class max_fourriere_fnc_searchFourriere {
    allowedTargets = 2;
};