#include "config_master.cpp"
#include "localization.hpp"
#include "dialogs\fourriere.hpp"